from __future__ import annotations
import sys, os, json
from pathlib import Path
from typing import Dict, Any
from atlas.io.jsonl import read_jsonl, write_jsonl

from __future__ import annotations
from typing import Dict, Any
from datetime import datetime

def stamp() -> str:
    return datetime.utcnow().isoformat() + "Z"

def stage_line(stage: str, status: str, metric: str|None, value: float|None, threshold: float|None, aux: Dict[str, Any], notes: str = "") -> Dict[str, Any]:
    return {
        "stage": stage,
        "status": status,
        "metric": metric,
        "value": value,
        "threshold": threshold,
        "aux": aux,
        "notes": notes,
        "timestamp": stamp()
    }


def _load_thresholds(cfg_path: str, profile: str = "default") -> Dict[str, Any]:
    with open(cfg_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    # allow both flat and profiles structure
    if "default" in cfg and isinstance(cfg["default"], dict):
        return cfg.get(profile, cfg["default"])
    return cfg

def eval_delta(cfg: Dict[str, Any], s: Dict[str, Any]) -> Dict[str, Any]:
    tau = float(cfg.get("tau_delta", 0.15))
    val = float(s["observables"]["Delta"])
    status = "PASS" if val <= tau else "WARN"
    return stage_line("delta", status, "delta_chart", val, tau, aux={})

def eval_nmod(cfg: Dict[str, Any], s: Dict[str, Any]) -> Dict[str, Any]:
    tau = float(cfg.get("tau_n", 0.05))
    val = abs(float(s["observables"]["deltaN"]))
    status = "PASS" if val <= tau else "WARN"
    return stage_line("nmod", status, "abs_delta_N", val, tau, aux={})

def eval_htop(cfg: Dict[str, Any], s: Dict[str, Any]) -> Dict[str, Any]:
    H_obs = float(s["observables"].get("H_obs", 0.0))
    plateau = bool(s.get("ground_truth",{}).get("H_plateau", False))
    # We treat plateau True as PASS for the stage; triage will use both plateau+Δ/N
    return stage_line("htop", "PASS" if plateau else "WARN", "H_obs", H_obs, None, aux={"H_plateau": plateau})

def triage(cfg: Dict[str, Any], d: Dict[str, Any], n: Dict[str, Any], h: Dict[str, Any]) -> Dict[str, Any]:
    tau_d = float(cfg.get("tau_delta", 0.15)); tau_n = float(cfg.get("tau_n", 0.05))
    H_plateau = bool(h["aux"].get("H_plateau", False))
    d_pass = (d["status"] == "PASS"); n_pass = (n["status"] == "PASS")
    if H_plateau and (not d_pass or not n_pass):
        cls = "true_tear"
    elif (not H_plateau) and (not d_pass or not n_pass):
        cls = "anomaly"
    elif H_plateau and d_pass and n_pass:
        cls = "hard_spot"
    else:
        cls = "fake"
    # confidence
    conf = min(1.0, 0.5*(float(d["value"])/tau_d + float(n["value"])/tau_n)) + (0.5 if H_plateau else 0.0)
    return stage_line("triage", "PASS", "class", None, None, aux={"class": cls, "confidence": conf})

def run(cfg_path: str, in_jsonl: str, out_jsonl: str, profile: str="default") -> None:
    cfg = _load_thresholds(cfg_path, profile)
    in_path = Path(in_jsonl)
    out_path = Path(out_jsonl)
    if not in_path.exists():
        # try repo-relative "data/toy.jsonl" fallback
        fallback = Path("data/toy.jsonl")
        if fallback.exists():
            in_path = fallback
        else:
            raise FileNotFoundError(f"Input JSONL not found: {in_jsonl} (and fallback {fallback} missing)")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    rows_out = []
    for s in read_jsonl(str(in_path)):
        d = eval_delta(cfg, s)
        n = eval_nmod(cfg, s)
        h = eval_htop(cfg, s)
        t = triage(cfg, d, n, h)
        rows_out.extend([d,n,h,t])
    write_jsonl(str(out_path), rows_out)

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python -m atlas.cli.run_pipeline <thresholds.json> <in.jsonl> <out.jsonl>")
        sys.exit(2)
    run(sys.argv[1], sys.argv[2], sys.argv[3])
