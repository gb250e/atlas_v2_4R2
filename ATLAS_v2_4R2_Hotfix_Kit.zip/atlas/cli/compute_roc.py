from __future__ import annotations
import sys, json, os
from typing import Iterable, Dict, Any, List, Tuple
from atlas.io.jsonl import read_jsonl

from __future__ import annotations
from typing import Dict, Any
from datetime import datetime

def stamp() -> str:
    return datetime.utcnow().isoformat() + "Z"

def stage_line(stage: str, status: str, metric: str|None, value: float|None, threshold: float|None, aux: Dict[str, Any], notes: str = "") -> Dict[str, Any]:
    return {
        "stage": stage,
        "status": status,
        "metric": metric,
        "value": value,
        "threshold": threshold,
        "aux": aux,
        "notes": notes,
        "timestamp": stamp()
    }


def compute_roc(results_jsonl: str, positives=("true_tear",)) -> Dict[str, Any]:
    tri = [r for r in read_jsonl(results_jsonl) if r.get("stage") == "triage"]
    scored: List[Tuple[float,bool]] = [(float(r["aux"]["confidence"]), r["aux"]["class"] in positives) for r in tri]
    scored.sort(key=lambda x: -x[0])
    P = sum(1 for _,y in scored if y); N = len(scored) - P
    if P == 0 or N == 0:
        return {"fpr":[0,1], "tpr":[0,1], "auc":0.5, "best_J":0.0, "threshold":1.0}
    fpr=[0.0]; tpr=[0.0]; ths=[1.1]
    tp=fp=0; prev=None
    for s,y in scored:
        tp += 1 if y else 0
        fp += 0 if y else 1
        if prev is None or s != prev:
            fpr.append(fp/N); tpr.append(tp/P); ths.append(s); prev=s
    auc=0.0
    for i in range(1,len(fpr)):
        auc += (fpr[i]-fpr[i-1]) * (tpr[i]+tpr[i-1]) / 2.0
    J=[tpr[i]-fpr[i] for i in range(len(fpr))]
    jm=max(range(len(J)), key=lambda i:J[i])
    return {"fpr":fpr, "tpr":tpr, "auc":auc, "best_J":J[jm], "threshold":ths[jm]}

def main(results_jsonl: str, out_json: str) -> None:
    if not os.path.exists(results_jsonl):
        raise FileNotFoundError(f"results_jsonl not found: {results_jsonl} — run the pipeline first.")
    r = compute_roc(results_jsonl)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(r, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python -m atlas.cli.compute_roc <results.jsonl> <roc.json>")
        sys.exit(2)
    main(sys.argv[1], sys.argv[2])
